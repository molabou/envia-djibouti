# ENVIA Djibouti — version corrigée

## Démarrage Windows
1. Démarrer Docker Desktop.
2. Fermer les anciens conteneurs ENVIA si ceux-ci occupent les ports 5173 ou 8000 (`docker ps`).
3. Double-cliquer sur `DEMARRER_ENVIA_CORRIGE.bat` ou exécuter `docker compose up --build -d` dans ce dossier.
4. Ouvrir http://localhost:5173 (Ctrl+F5 pour vider le cache).

## Diagnostic
- `docker compose ps`
- `docker compose logs --tail=100 frontend`
- `docker compose logs --tail=100 backend`
- `http://localhost:8000/health`
- `http://localhost:5173/api-server/health` (proxy API)

Le port 5432 n'est plus exposé sur Windows, mais PostgreSQL reste disponible pour le backend dans le réseau Docker. Les données existantes ne sont pas effacées par `up --build -d`. **Ne pas lancer `docker compose down -v`** si vous souhaitez conserver les données.

L'application utilise un proxy Vite pour éviter les erreurs de CORS et les appels API à localhost incorrects. Une page d'erreur explicite apparaît en cas d'erreur de rendu React, avec bouton de réinitialisation de session.

**Note de validation :** vérifications statiques réalisées ; Docker n'est pas disponible dans l'environnement de préparation. Tester les conteneurs sur votre poste avec les commandes ci-dessus.
