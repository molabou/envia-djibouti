# ENVIA — interface écogarde simplifiée
Cette variante conserve la structure initiale et supprime le bouton « Analyser avec l'IA ».
Le mode simplifié permet de prendre une photo et de l'envoyer avec le GPS.
Le mode assisté conserve les champs facultatifs de saisie/correction.
IMPORTANT : l'analyse IA après réception côté serveur n'est PAS encore reliée au traitement des signalements. L'endpoint /api/v1/ai/analyze-photo existe, mais le déclenchement automatique après réception, le traitement différé et la validation doivent être intégrés et testés avant production.
Aucun déploiement ni nouvel APK n'a été effectué.
