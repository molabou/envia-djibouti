@echo off
cd /d "%~dp0"
echo ========================================
echo        ENVIA DJIBOUTI V1
 echo ========================================
echo.
echo Demarrage de la plateforme...
docker compose up --build
pause
