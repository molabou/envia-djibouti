# ENVIA Djibouti V1 — édition fonctionnelle

Cette version corrige le démarrage du backend et ajoute une interface opérationnelle pour le test local.

## 1. Prérequis
- Docker Desktop lancé
- Windows 10/11 ou macOS/Linux

## 2. Démarrage
Dans ce dossier :

```bash
docker compose down
docker compose up --build
```

Attendre que les trois services soient `Up` : `db`, `backend`, `frontend`.

## 3. Ouvrir
- Application : http://localhost:5173
- API : http://localhost:8000
- Documentation : http://localhost:8000/docs
- Santé : http://localhost:8000/health

## 4. Comptes de démonstration
- Écogarde : `ecogarde` / `ecogarde123`
- Expert : `expert` / `expert123`
- Admin : `admin` / `admin123`
- Citoyen : `citoyen` / `citoyen123`

## 5. Fonctionnalités V1
- Connexion et profils
- Tableau de bord
- Signalements avec GPS, photo et audio
- Assistance ENVIA-AI locale pour proposer une catégorie à partir d'une description
- Validation humaine
- Carte des signalements
- Points de collecte de déchets de démonstration
- Centre d'alertes
- Statistiques
- API FastAPI
- PostgreSQL/PostGIS
- stockage des médias

## Important sur l'IA
Le moteur `ENVIA-AI-local-v1` inclus ici est un moteur de démonstration/règles : il ne fait pas encore de vraie vision par ordinateur ni de transcription audio. Il est conçu comme point d'intégration pour un service IA réel. Toute suggestion reste soumise à validation humaine.

## Réinitialiser complètement les données
Si nécessaire :

```bash
docker compose down -v
docker compose up --build
```

Cela supprime la base de démonstration et la recrée.
