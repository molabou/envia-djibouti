ENVIA Mobile - interface photo seule.
Compte ecogarde: mode simplifie par defaut, aucun formulaire, bouton photo puis envoyer.
Compte ecogarde avance: le backend devra renvoyer ecogarde_mode='assisted' dans l'objet utilisateur; la gestion de ce champ par l'administration reste a implementer.
ATTENTION: l'analyse IA automatique APRES reception n'est pas encore branchee sur la file serveur. Ce ZIP ne doit pas etre presente comme une solution IA terminee.
La capture GPS requiert HTTPS ou localhost et l'autorisation de localisation.
