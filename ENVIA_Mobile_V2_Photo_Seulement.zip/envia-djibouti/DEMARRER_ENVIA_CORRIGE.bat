@echo off
cd /d "%~dp0"
docker compose up --build -d
docker compose ps
echo.
echo Ouvrez http://localhost:5173
pause
