# ENVIA Terrain V2 — prototype intégré au projet d'origine

## Ajouts
- Écran « Signalement intelligent IA / Nid de tortue » accessible depuis l'accueil mobile.
- Deux modes d'interface : simplifié et assisté. Ils sont sélectionnables dans l'interface ; l'attribution administrative par compte n'est pas encore implémentée.
- Capture photo et GPS, mise en file d'attente locale des signalements, synchronisation via le mécanisme existant.
- Analyse visuelle via `/api/v1/ai/analyze-photo` : nécessite `OPENAI_API_KEY` configurée côté serveur. Sans clé ou sans réseau, le signalement reste possible mais sera à classifier par un expert.
- Création de points « nids de tortue » avec coordonnées masquées à la réponse de création ; consultation complète réservée au rôle expert.
- Endpoint `/api/v1/map/validated` et filtrage des listes de la carte mobile pour n'afficher que les signalements validés, traités ou clôturés.

## Limitations et sécurité avant mise en production
- L'IA est appelée au moment de l'envoi, pas en prévisualisation. Le mode assisté doit être amélioré pour permettre de relire et corriger **après** l'analyse IA.
- Le formulaire GPS « nid » exige une connexion ; sa synchronisation hors ligne et son suivi chronologique restent à développer.
- Les nids n'ont pas de photo ni de fiche de suivi des éclosions dans cette version.
- Les comptes écogardes n'ont pas encore de sous-profil administrable « simplifié/avancé ».
- Vérifier toutes les autres routes API/export/cartes afin d'éviter la diffusion de données de biodiversité sensibles.
- La carte mobile actuelle n'affiche qu'un point sélectionné ; les marqueurs multiples sont à développer.
- Le backend existant et sa configuration d'authentification doivent faire l'objet d'un audit avant exposition sur Internet.
- Ne pas déployer tel quel en production sans tests automatisés et vérification des migrations.
- L'APK original fourni n'a pas été modifié ni recompilé. Pour obtenir un nouvel APK, un environnement de compilation Android adapté est nécessaire.
