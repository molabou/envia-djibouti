@echo off
cd /d "%~dp0"
echo Etat des services ENVIA :
docker compose ps
echo.
echo Test API :
curl -s http://localhost:8000/health
echo.
pause
